#ifndef TM_DEFINES_H
#define TM_DEFINES_H

/* Uncomment if you want to enable USB HS in FS mode */
/* Used on STM32F429 Discovery board */
/* By default, USB FS mode is used */
//#define USE_USB_OTG_HS
#endif
